import 'package:exercise/components/favorite_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:share_plus/share_plus.dart';

import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

class HomeList extends StatefulWidget {
  HomeList({super.key});

  @override
  State<HomeList> createState() => _HomeListState();
}

class _HomeListState extends State<HomeList> {
  @override
  Widget build(BuildContext context) {
    final List<String> imageList = [
      'https://png.pngtree.com/element_our/png/20181129/vector-illustration-of-fresh-red-apple-with-single-leaf-png_248312.jpg',
      'https://i.ytimg.com/vi/dRC7XDGlrO4/frame0.jpg',
      'https://png.pngtree.com/thumb_back/fh260/background/20191120/pngtree-sunset-nature-landscape-with-big-tree-image_322506.jpg',
      'https://i0.wp.com/www.teahub.io/photos/full/301-3019765_pemandangan.jpg'
    ];
    final List<String> items = [
      'Rivaldi Master of Ceremony',
      'budi Veteran player',
      'Non Character Player',
      'whatsapp'
    ];
    final List<String> subitems = [
      'Super active player',
      'Player Genshin impact',
      'silent forever at university or school',
      'wa.me/settings'
    ];

    final provider = favoriteproakses.of(context);

    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(imageList[index]),
          ),
          title: Text(items[index]),
          subtitle: Text(subitems[index]),
          trailing: Icon(Icons.keyboard_arrow_right_outlined),
          onTap: () {
            showBottomSheet(
                enableDrag: true,
                context: context,
                builder: (context) {
                  final theme = Theme.of(context);
                  return Wrap(
                    children: [
                      ListTile(
                        title: Text(
                          'Select Action',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: Colors.white),
                        ),
                        tileColor: theme.colorScheme.primary,
                        trailing: IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: Icon(
                              Icons.close,
                              color: Colors.white,
                            )),
                      ),
                      ListTile(
                        title: Text('Send Name'),
                        trailing: IconButton(
                            onPressed: () {
                              Share.share(items[index]);
                              Navigator.pop(context);
                            },
                            icon: Icon(
                              Icons.perm_identity_outlined,
                            )),
                      ),
                      ListTile(
                        title: Text('Copy Status'),
                        trailing: IconButton(
                            onPressed: () {
                              Clipboard.setData(
                                  ClipboardData(text: subitems[index]));
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content:
                                      Text(subitems[index] + ' Telah Disalin'),
                                  duration: Duration(seconds: 3),
                                  action: SnackBarAction(
                                      label: 'Dismiss', onPressed: () {}),
                                ),
                              );
                              Navigator.pop(context);
                            },
                            icon: Icon(
                              Icons.copy,
                            )),
                      ),
                      ListTile(
                        title: Text('Favorite'),
                        trailing: IconButton(
                            onPressed: () {
                              provider.toggleFavorite(item);
                              Clipboard.setData(
                                  ClipboardData(text: items[index]));
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Favorite ' + items[index]),
                                  duration: Duration(seconds: 2),
                                  action: SnackBarAction(
                                      label: 'Dismiss', onPressed: () {}),
                                ),
                              );
                              Navigator.pop(context);
                            },
                            icon: provider.isExist(item)
                                ? Icon(
                                    Icons.favorite,
                                    color: Colors.red,
                                  )
                                : Icon(Icons.favorite_border)),
                      ),
                    ],
                  );
                });
          },
        );
      },
    );
  }
}
