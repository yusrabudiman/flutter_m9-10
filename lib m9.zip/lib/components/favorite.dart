import 'package:exercise/components/favorite_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Favorite extends StatefulWidget {
  const Favorite({super.key});

  @override
  State<Favorite> createState() => _FavoriteState();
}

class _FavoriteState extends State<Favorite> {
  @override
  Widget build(BuildContext context) {
    final provider = favoriteproakses.of(context);
    final items = provider.item;
    return Scaffold(
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return ListTile(
            title: Text(items[index]),
            trailing: IconButton(
              onPressed: () {
                provider.toggleFavorite(item);
                Clipboard.setData(ClipboardData(text: item[index]));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('User Telah Dihapus'),
                    duration: Duration(seconds: 1),
                  ),
                );
              },
              icon: provider.isExist(item)
                  ? Icon(Icons.favorite, color: Colors.red)
                  : Icon(Icons.favorite_border),
            ),
          );
        },
      ),
    );
  }
}
