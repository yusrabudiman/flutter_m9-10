import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class favoriteproakses extends ChangeNotifier {
  var light = ThemeData(
    brightness: Brightness.light,
    primarySwatch: Colors.purple,
  );

  var dark = ThemeData(
    brightness: Brightness.dark,
    primarySwatch: Colors.purple,
  );

  bool _enableDarkMode = false;

  bool get enableDarkMode => _enableDarkMode;

  set setBrightness(val) {
    _enableDarkMode = val;
    notifyListeners();
  }

  bool _isDropdownVisible = false;

  bool get isDropdownShow => _isDropdownVisible;

  set isDropdownShow(value) {
    _isDropdownVisible = value;
    notifyListeners();
  }

  //Add favorite remove
  List<String> _items = [];
  List<String> get item => _items;

  void toggleFavorite(String item) {
    final isExist = _items.contains(item);
    if (isExist) {
      _items.remove(item);
    } else {
      _items.add(item);
    }
    notifyListeners();
  }

  bool isExist(String item) {
    final isExist = _items.contains(item);
    return isExist;
  }

  void clearFavorite() {
    _items = [];
    notifyListeners();
  }

  static favoriteproakses of(
    BuildContext context, {
    bool listen = true,
  }) {
    return Provider.of<favoriteproakses>(
      context,
      listen: listen,
    );
  }
}
