import 'package:exercise/components/favorite_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:provider/provider.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  // bool isSwitch = false;
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<favoriteproakses>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Padding(
        padding: EdgeInsets.all(18.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Darkmode mode theme'),
                Switch(
                    value: prov.enableDarkMode,
                    activeColor: Colors.purple,
                    onChanged: (val) {
                      prov.setBrightness = val;
                    })
              ],
            ),
            // TextButton(
            //   onPressed: () {
            //     print('Settings');
            //   },
            //   child: Text('Settings'),
            // ),
          ],
        ),
      ),
    );
  }
}
