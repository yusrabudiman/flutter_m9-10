import 'package:exercise/components/favorite_provider.dart';
import 'package:exercise/components/homelist.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'components/favorite.dart';
import 'components/settings.dart';

void main() {
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(create: (_) => favoriteproakses()),
  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<favoriteproakses>(context);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: prov.enableDarkMode == true ? prov.dark : prov.light,
      home: Pertemuan09Screen(),
    );
  }
}

class Pertemuan09Screen extends StatefulWidget {
  const Pertemuan09Screen({super.key});

  @override
  State<Pertemuan09Screen> createState() => _Pertemuan09ScreenState();
}

class _Pertemuan09ScreenState extends State<Pertemuan09Screen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, //set tab bar view
      child: Scaffold(
        appBar: AppBar(
          title: Text('Pertemuan 09'),
          bottom: TabBar(isScrollable: true, tabs: [
            Tab(
              child: Text('User'),
            ),
            Tab(
              child: Text('Favorite'),
            ),
            // Tab(
            //   child: Text('Saved'),
            // ),
          ]),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(color: Colors.purple),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      child: Image.asset('assets/twitter logo.jpg'),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Dani',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'dani@gmail.com',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Divider(),
              ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Settings()));
                },
                leading: Icon(Icons.settings),
                title: Text('Settings'),
                trailing: Icon(Icons.keyboard_arrow_right_outlined),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            HomeList(),
            Favorite(),
            // Saved(),
            // TextButton(
            //   onPressed: () {
            //     print('Saved');
            //   },
            //   child: Text('Saved'),
            // ),
          ],
        ),
      ),
    );
  }
}
